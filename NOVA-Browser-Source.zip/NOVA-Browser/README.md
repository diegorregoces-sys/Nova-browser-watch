# NOVA Browser for Samsung Galaxy Watch Ultra

A starter Wear OS browser written in Kotlin using Android WebView. Package: `com.nova.browser`.

## Included in this first build
- Search/address field (DuckDuckGo search by default)
- Back, forward, reload, home controls
- WebView with JavaScript and DOM storage enabled for site compatibility
- Pop-up windows and automatic JavaScript-created windows disabled
- Third-party cookies disabled
- Safe Browsing enabled where supported
- HTTPS-only mixed-content policy; file/content access disabled
- Local host and URL-fragment request filtering, with an on/off shield control

## Important ad-blocking limitation
This is an initial, offline ruleset—not a complete EasyList/uBlock Origin engine. It blocks a curated set of common ad/tracker hosts and URL patterns, and blocks many pop-up/redirect techniques. It cannot guarantee removal of first-party ads, ads served from the same domain as the page, or every new advertising domain. The blocked counter counts blocked requests and may include subresources, not only visible ads. Do not describe this as 100% ad blocking.

## Build an APK
1. Install the current Android Studio on a computer.
2. Install Android SDK Platform 35 and a compatible Android SDK Build-Tools through SDK Manager.
3. Open this `NOVA-Browser` folder in Android Studio and allow Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The project source is provided for opening and building in Android Studio.

## Install on the watch
Enable Developer options and ADB debugging on the watch, connect it to the same Wi-Fi network as your computer (or use wireless debugging), then install with:

```bash
adb connect WATCH_IP:5555
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Use the actual IP and port shown by the watch's Wireless debugging screen. Menu names vary by Wear OS version.
