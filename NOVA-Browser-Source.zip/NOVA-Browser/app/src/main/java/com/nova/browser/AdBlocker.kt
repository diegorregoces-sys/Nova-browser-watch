package com.nova.browser

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.Locale

/** Lightweight local request filter. This is a starter list, not a full EasyList implementation. */
object AdBlocker {
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com", "adnxs.com",
        "adsrvr.org", "taboola.com", "outbrain.com",
        "criteo.com", "criteo.net", "scorecardresearch.com", "zedo.com",
        "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
        "adsterra.com", "trafficjunky.com", "juicyads.com", "revcontent.com",
        "mgid.com", "smartadserver.com", "adform.net", "rubiconproject.com",
        "openx.net", "pubmatic.com", "casalemedia.com", "sharethrough.com",
        "lijit.com", "analytics.yahoo.com", "hotjar.com", "clarity.ms"
    ).map { it.trim().lowercase(Locale.ROOT) }.filter { it.isNotEmpty() }.toSet()

    private val blockedUrlFragments = listOf(
        "/ads/", "/adserver/", "/advertising/", "/popunder/", "/popup/",
        "doubleclick", "googlesyndication", "adservice", "affiliate\\_banner"
    )

    fun isBlocked(url: String): Boolean {
        val host = runCatching { java.net.URI(url).host?.lowercase(Locale.ROOT) }.getOrNull() ?: return false
        if (blockedHosts.any { host == it || host.endsWith(".$it") }) return true
        val lower = url.lowercase(Locale.ROOT)
        return blockedUrlFragments.any { lower.contains(it) }
    }

    fun emptyResponse(): WebResourceResponse = WebResourceResponse(
        "text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )
}
