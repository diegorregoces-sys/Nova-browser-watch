package com.nova.browser

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.webkit.*
import android.widget.*
import android.text.InputType
import java.net.URLEncoder

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var shield: TextView
    private var blockedCount = 0
    private var adBlockEnabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildInterface()
        configureWebView()
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://duckduckgo.com")
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(8, 11, 18))
        }
        val brand = TextView(this).apply {
            text = "NOVA  •  BROWSER"
            setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(6))
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, -2))

        address = EditText(this).apply {
            hint = "Search or enter URL"; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            textSize = 12f; singleLine = true; inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(12), 0, dp(8), 0)
            background = rounded(Color.rgb(35, 43, 57), dp(22))
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(address.text.toString()); hideKeyboard(); true
                } else false
            }
        }
        root.addView(address, LinearLayout.LayoutParams(-1, dp(42)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
        shield = TextView(this).apply { text = "● PROTECTION ON"; textSize = 9f; setTextColor(Color.rgb(98, 214, 165)) }
        status = TextView(this).apply { text = "  •  0 blocked"; textSize = 9f; setTextColor(Color.LTGRAY) }
        info.addView(shield); info.addView(status)
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this).apply { setBackgroundColor(Color.WHITE) }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
        }
        fun control(label: String, action: () -> Unit) {
            val b = TextView(this).apply {
                text = label; textSize = 16f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); background = rounded(Color.rgb(35, 43, 57), dp(18))
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(2); marginEnd = dp(2) }
            controls.addView(b, lp)
        }
        control("‹") { if (web.canGoBack()) web.goBack() }
        control("›") { if (web.canGoForward()) web.goForward() }
        control("↻") { web.reload() }
        control("⌂") { web.loadUrl("https://duckduckgo.com") }
        control("盾") { adBlockEnabled = !adBlockEnabled; updateProtectionLabel() }
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun configureWebView() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
            override fun onReceivedTitle(view: WebView?, title: String?) { if (!title.isNullOrBlank()) address.setText(view?.url ?: "") }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return true
                if (!url.startsWith("https://") && !url.startsWith("http://")) return true
                if (adBlockEnabled && AdBlocker.isBlocked(url)) { countBlocked(); return true }
                address.setText(url)
                return false
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                if (adBlockEnabled && AdBlocker.isBlocked(url)) { countBlocked(); return AdBlocker.emptyResponse() }
                return null
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null) address.setText(url)
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != null) address.setText(url)
            }
        }
    }

    private fun navigate(raw: String) {
        var value = raw.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://duckduckgo.com/?q=" + URLEncoder.encode(value, "UTF-8")
        }
        web.loadUrl(url)
    }

    private fun countBlocked() {
        runOnUiThread { blockedCount++; status.text = "  •  $blockedCount blocked" }
    }
    private fun updateProtectionLabel() {
        shield.text = if (adBlockEnabled) "● PROTECTION ON" else "● PROTECTION OFF"
        shield.setTextColor(if (adBlockEnabled) Color.rgb(98, 214, 165) else Color.YELLOW)
    }
    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0)
        address.clearFocus()
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::web.isInitialized) { web.stopLoading(); web.destroy() }; super.onDestroy() }
}
