NOVA Browser - GitHub Actions build setup

1. Create a NEW GitHub repository (public or private).
2. Upload NOVA-Browser-Source.zip to the repository root.
3. In the repository choose Add file > Create new file.
4. Name the file exactly: .github/workflows/android.yml
5. Paste the contents of android.yml from this setup pack and commit it to the main branch.
6. Open the Actions tab. Choose Build NOVA Browser APK and tap Run workflow if it did not start automatically.
7. Open the completed run and download the artifact named NOVA-Browser-debug-apk. It contains app-debug.apk.

Important: this compiles the current starter project. Its ad filter is a curated starter list, not a full EasyList/uBlock engine, and cannot guarantee blocking all ads or redirects.
